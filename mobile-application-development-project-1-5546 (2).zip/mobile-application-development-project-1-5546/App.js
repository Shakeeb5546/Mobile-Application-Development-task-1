import React, { useState, useEffect } from "react";

const AnimatedCard = () => {
    const [bgColor, setBgColor] = useState(["#667eea", "#764ba2"]);
    const colors = ["#667eea", "#764ba2", "#ff9a9e", "#fad0c4"];
    let index = 0;

    useEffect(() => {
        const interval = setInterval(() => {
            setBgColor([colors[index], colors[(index + 1) % colors.length]]);
            index = (index + 1) % colors.length;
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
            background: `linear-gradient(135deg, ${bgColor[0]}, ${bgColor[1]})`,
            fontFamily: "Arial, sans-serif"
        }}>
            <div style={{
                width: "300px",
                padding: "20px",
                textAlign: "center",
                borderRadius: "15px",
                boxShadow: "0 10px 30px rgba(0, 0, 0, 0.3)",
                background: `linear-gradient(135deg, ${bgColor[0]}, ${bgColor[1]})`,
                color: "white",
                transform: "scale(1)",
                transition: "transform 0.3s ease-in-out"
            }}
            onMouseOver={(e) => e.currentTarget.style.transform = "scale(1.1)"}
            onMouseOut={(e) => e.currentTarget.style.transform = "scale(1)"}
            >
                <h1>Muhammad Shakeeb Hashir</h1>
                <p>5546</p>
                <p>Hello World</p>
            </div>
        </div>
    );
};

export default AnimatedCard;
